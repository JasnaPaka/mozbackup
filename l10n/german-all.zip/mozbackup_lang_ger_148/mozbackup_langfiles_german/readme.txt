German languagefiles for MozillaBackup / MozBackup
-----------------------------------------------------
MozBackup is freeware from:
Programmer:      Pavel Cvrcek
eMail:           jasnapaka@jasnapaka.com
Website:         http://www.jasnapaka.com/
Project homepage: http://mozbackup.jasnapaka.com/
English Homepage: http://mozbackup.jasnapaka.com/
-----------------------------------------------------
Translator:      Ralf Hinrichsen
eMail:           rh.hinne@t-online.de
Website:         www.germanja.de

Corrections		 Armin Jakob
-----------------------------------------------------

Zipfile:	mozbackup_langfiles_german.zip
Filedate:	04/25/2004|03:00PM GMT+1
Update:		05/18/2008|17:00PM GMT+1
		- added german langfile for MozBackup V 1.4.8

includes:
readme.txt (this file..:))

dir:  mozbackup122/default.lng
File translated to german for Mozbackup v1.2.2

dir:  mozbackup13b/default.lng
File translated to german for Mozbackup v1.3 beta

dir:  mozbackup13x/default.lng
File translated to german for Mozbackup v1.3, 1.3.1

dir:  mozbackup140/default.lng
File translated to german for Mozbackup v1.40

dir:  mozbackup142/default.lng
File translated to german for Mozbackup v1.4.2

dir:  mozbackup143-146/default.lng
File translated to german for Mozbackup v1.4.3 to v1.4.6

dir:  mozbackup147/default.lng
File translated to german for Mozbackup v1.4.7

dir:  mozbackup148/default.lng
File translated to german for Mozbackup v1.4.8

* Installation:
- Make a backup of your old 'default.lng' file.
- Copy the right 'default.lng' file for your Mozbackup version out of this *.zip
  into the program folder of installed Mozbackup.
- Overwrite the old file.
- Restart Mozbackup.
- Ready!

* Notes
- Use at your own risk.
- Thanks to Armin Jakob for his corrections.
- Thanks to Pavel for this great tool!
- And thanks to all people who remind me of new versions of Mozbackup ;-)